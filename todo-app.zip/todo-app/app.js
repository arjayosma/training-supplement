const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const pageRoutes = require("./src/routes/pages");
const app = express();

app.set("views", `${__dirname}/src/templates`);
app.set("view engine", "html");
app.engine("html", ejs.renderFile);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(`${__dirname}/src/public`));
pageRoutes(app);

module.exports = app;
