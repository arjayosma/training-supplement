$(document).ready(function() {
  $("#btnAddTask").click(function(event) {
    event.preventDefault();
    var task = $("#txtTask").val();
    $.ajax({
      url: "/",
      type: "POST",
      dataType: "json",
      data: {
        task: task
      },
      success: function(result) {
        $(".list-group").append(
          `<a href="/task?id=${
            result.id
          }" class="list-group-item"><span class="text-dark">${
            result.data.date
          }</span> - ${result.data.task}</a>`
        );
        $("#txtTask").val("");
      },
      error: function(error) {
        console.log(error);
      }
    });
  });

  $("#btnDeleteTask").click(function(event) {
    event.preventDefault();
    var params = new URLSearchParams(window.location.search);
    var id = params.get("id");
    $.ajax({
      url: "/task",
      type: "DELETE",
      dataType: "json",
      data: {
        id: id
      },
      success: function(result) {
        if (result) {
          alert("Task has been deleted!");
          window.location.href = "/";
        }
      },
      error: function(error) {
        console.log(error);
      }
    });
  });
});
