const fs = require("fs");

module.exports = function(app) {
  app.get("/", function(request, response) {
    const tasks = require("../public/data/tasks.json");
    response.render("task-list", { taskList: tasks });
  });

  app.post("/", function(request, response) {
    var tasks = require("../public/data/tasks.json");
    const task = request.body.task;
    const date = new Date();
    const data = {
      date: date,
      task: task
    };
    tasks.push(data);
    fs.writeFile("src/public/data/tasks.json", JSON.stringify(tasks), function(
      error
    ) {
      if (!error) {
        response.json({ id: tasks.length, data: data });
      } else {
        response.end("An error has occurred!");
      }
    });
  });

  app.get("/task", function(request, response) {
    var index = request.query.id;
    const tasks = require("../public/data/tasks.json");
    response.render("task", { data: tasks[index - 1] });
  });

  app.delete("/task", function(request, response) {
    var index = request.body.id;
    var tasks = require("../public/data/tasks.json");
    tasks.splice(index - 1, 1);
    fs.writeFile("src/public/data/tasks.json", JSON.stringify(tasks), function(
      error
    ) {
      if (!error) {
        response.json({ success: true });
      } else {
        response.end("An error has occurred!");
      }
    });
  });
};
